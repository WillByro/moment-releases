// Kairos window. State comes from Python (window.pywebview.api.state) once a second.

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const ICONS = {
  focus: '<circle cx="8" cy="8" r="6"/><circle cx="8" cy="8" r="2"/>',
  activity: '<path d="M1.5 8h3l2-5 3 10 2-5h3"/>',
  schedule: '<rect x="2" y="3" width="12" height="11" rx="2"/><path d="M2 6.5h12M5.5 1.5v3M10.5 1.5v3"/>',
  settings: '<path d="M2 4.5h7M12 4.5h2M2 11.5h2M7 11.5h7"/><circle cx="10.5" cy="4.5" r="1.5"/><circle cx="5.5" cy="11.5" r="1.5"/>',
  about: '<circle cx="8" cy="8" r="6"/><path d="M8 7.5v3.5M8 5h.01"/>',
  accountability: '<rect x="1.5" y="3.5" width="13" height="9" rx="1.5"/><path d="m2 4.5 6 4.5 6-4.5"/>',
  lock: '<rect x="3" y="7" width="10" height="7" rx="1.5"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/>',
};
const icon = (name) =>
  `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${ICONS[name]}</svg>`;

const PAGES = [["focus", "Focus"], ["activity", "Activity"], ["schedule", "Schedule"], ["accountability", "Accountability"],
               ["settings", "Settings"], ["about", "About"]];
const DURATIONS = [[25, "25 min"], [50, "50 min"], [90, "1.5 hours"], [120, "2 hours"], [240, "4 hours"], [0, "Custom"]];
const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const EVENT_LABEL = { allowed: "Allowed", blocked: "Blocked", closed: "Closed", granted: "Granted", denied: "Denied", expired: "Expired", revoked: "Revoked" };

let S = null;          // latest state from Python
let page = "focus";
let duration = 50;
let settingsLoaded = false;
let accountabilityLoaded = false;
let chosenTier = null;
const dayOn = new Set(["mon", "tue", "wed", "thu", "fri"]);

const api = () => window.pywebview.api;

// Fill a list container, or show its empty state, without replacing the element.
function fill(id, rows, emptyText) {
  const el = $(id);
  el.className = rows.length ? "list" : "empty";
  el.innerHTML = rows.length ? rows.join("") : esc(emptyText);
}

// ---------- formatting ----------

function clock(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function short(sec) {
  sec = Math.max(0, Math.round(sec));
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60), s = sec % 60;
  return m < 60 ? `${m}:${String(s).padStart(2, "0")}` : `${Math.floor(m / 60)}h ${m % 60}m`;
}
function hm(sec) {
  const m = Math.round(sec / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, "0")}m`;
}
const money = (d) => (d >= 0.01 ? `$${d.toFixed(2)}` : d > 0 ? "<$0.01" : "$0.00");
const cents = (c) => (c >= 0.1 ? `${c.toFixed(1)}¢` : "<0.1¢");
const timeOf = (t) => new Date(t * 1000).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
function parseDuration(text) {
  const m = String(text).trim().toLowerCase().match(/^(?:(\d+)\s*h)?\s*(?:(\d+)\s*m?)?$/);
  if (!m || (!m[1] && !m[2])) return 0;
  return (+m[1] || 0) * 60 + (+m[2] || 0);
}

// ---------- navigation ----------

function buildNav() {
  $("nav").innerHTML = PAGES.map(([id, label]) =>
    `<button class="nav-item" data-page="${id}">${icon(id)}<span>${label}</span></button>`).join("");
  $("nav").addEventListener("click", (e) => {
    const b = e.target.closest("[data-page]");
    if (b) show(b.dataset.page);
  });
}

function show(id) {
  page = id;
  for (const [p] of PAGES) $(`page-${p}`).classList.toggle("hidden", p !== id);
  document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.page === id));
  if (id === "settings") settingsLoaded = false;
  if (id === "accountability") accountabilityLoaded = false;
  render();
}

// ---------- modal ----------

function confirmDialog({ title, body, ok, danger = false, check = null }) {
  $("modal-title").textContent = title;
  $("modal-body").textContent = body;
  $("modal-ok").textContent = ok;
  $("modal-ok").className = `btn ${danger ? "btn-danger" : "btn-primary"}`;
  $("modal-check").classList.toggle("hidden", !check);
  if (check) { $("modal-check-label").textContent = check; $("modal-check-input").checked = false; }
  $("modal").classList.remove("hidden");
  return new Promise((resolve) => {
    const done = (v) => {
      $("modal").classList.add("hidden");
      $("modal-ok").onclick = $("modal-cancel").onclick = null;
      resolve(v && { checked: $("modal-check-input").checked });
    };
    $("modal-ok").onclick = () => done(true);
    $("modal-cancel").onclick = () => done(false);
  });
}

// ---------- Focus ----------

function buildFocus() {
  $("durations").innerHTML = DURATIONS.map(([m, label]) =>
    `<button data-min="${m}" class="${m === duration ? "active" : ""}">${label}</button>`).join("");
  $("durations").addEventListener("click", (e) => {
    const b = e.target.closest("[data-min]");
    if (!b) return;
    duration = +b.dataset.min;
    $("durations").querySelectorAll("button").forEach((x) => x.classList.toggle("active", x === b));
    $("custom-duration").classList.toggle("hidden", duration !== 0);
    if (duration === 0) $("custom-duration").focus();
  });

  $("start").onclick = async () => {
    const scope = $("scope").value.trim();
    const minutes = duration || parseDuration($("custom-duration").value);
    $("start-error").textContent = "";
    if (scope.length < 8) return ($("start-error").textContent = "Describe what you're working on first.");
    if (!minutes) return ($("start-error").textContent = "Enter a duration like 45m or 1h30m.");
    const locked = $("lock").checked;
    if (locked && !(await confirmDialog({
      title: "Lock this session?",
      body: `You won't be able to end it for ${hm(minutes * 60)}. You can still add time.`,
      ok: "Start locked session",
    }))) return;
    const r = await api().start(scope, minutes, locked);
    if (r.error) {
      $("start-error").textContent = r.error;
      if (r.goto) show(r.goto);
    }
    poll();
  };

  document.querySelectorAll("[data-extend]").forEach((b) =>
    (b.onclick = async () => { await api().extend(+b.dataset.extend); poll(); }));
  $("emergency").onclick = async () => {
    const { left, of } = S.emergency;
    if (!(await confirmDialog({
      title: "Use an emergency stop?",
      body: `This ends your locked session now. You get ${of} emergency stops, ever, and this uses one: ` +
            `${left - 1 === 0 ? "it's your last" : `${left - 1} will be left`}.`,
      ok: "End session now", danger: true,
    }))) return;
    const r = await api().emergency_stop();
    $("session-error").textContent = r.error || "";
    poll();
  };
  $("end").onclick = async () => {
    if (!(await confirmDialog({ title: "End this session?", body: "Blocking stops right away.", ok: "End session" }))) return;
    await api().stop();
    poll();
  };
}

function renderFocus() {
  const s = S.session;
  $("focus-idle").classList.toggle("hidden", !!s);
  $("focus-active").classList.toggle("hidden", !s);

  if (!s) {
    const today = S.events.filter((e) => new Date(e.t * 1000).toDateString() === new Date().toDateString());
    const count = (k) => today.filter((e) => e.kind === k).length;
    const granted = today.filter((e) => e.kind === "granted").reduce((a, e) => a + (e.minutes || 0), 0);
    $("today-stats").innerHTML = [
      ["Focused today", hm(S.usage.today_hours * 3600)],
      ["Blocked", count("blocked") + count("closed")],
      ["Time granted", `${granted} min`],
      ["Spent today", money(S.usage.today_cost)],
    ].map(([l, v]) => `<div class="stat"><div class="stat-label">${l}</div><div class="stat-value">${v}</div></div>`).join("");
    return;
  }

  $("timer").textContent = clock(s.remaining);
  const ends = new Date(Date.now() + s.remaining * 1000).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  $("timer-sub").textContent = `Ends at ${ends}${s.source === "schedule" ? " · Scheduled block" : ""}`;
  $("progress-fill").style.width = `${Math.max(0, Math.min(100, (s.remaining / (s.total || s.remaining)) * 100))}%`;
  $("active-scope").textContent = s.scope;
  $("lock-badge").innerHTML = s.locked ? `<span class="badge lock">${icon("lock")}Locked</span>` : `<span class="badge neutral">Unlocked</span>`;
  $("end").disabled = !!s.locked;
  $("end").title = s.locked ? "Locked sessions can't be ended early" : "";
  const canEscape = s.locked && S.config.emergency_stop && S.emergency.left > 0;
  $("emergency").classList.toggle("hidden", !canEscape);
  $("emergency").textContent = `Emergency stop (${S.emergency.left} left)`;

  fill("grants", S.grants.map((g) => `
    <div class="item">
      <div class="item-main"><div class="item-title">${esc(g.name)}</div><div class="item-sub">${esc(g.condition)}</div></div>
      <div class="item-time">${g.left == null ? "This session" : `${short(g.left)} left`}</div>
    </div>`), "Nothing beyond your core tools. When something's blocked, ask for time from the banner.");
}

// ---------- Activity ----------

function renderActivity() {
  const u = S.usage;
  const tier = S.tiers.find((t) => t.id === S.config.tier) || S.tiers[1];
  const perHour = u.cost_per_hour ?? (8 * tier.cents) / 100; // ~8 new apps or sites an hour until there's data
  $("usage-stats").innerHTML = [
    ["Spent today", money(u.today_cost), `${u.today_checks} checks`],
    ["Projected day", money(perHour * 8), u.cost_per_hour == null ? "Estimate, 8 hours" : "8 hours at your pace"],
    ["Focused today", hm(u.today_hours * 3600), ""],
    ["Per check", u.cost_per_check == null ? cents(tier.cents) : cents(u.cost_per_check * 100), tier.label],
  ].map(([l, v, n]) => `<div class="stat"><div class="stat-label">${l}</div><div class="stat-value">${v}</div><div class="stat-note">${n || "&nbsp;"}</div></div>`).join("");
  $("usage-note").textContent = u.cost_per_hour == null
    ? "The projection assumes about 8 new apps or sites an hour until there's 15 minutes of real data."
    : "Apps and sites already checked are free for the rest of the session.";

  fill("events", S.events.slice(0, 60).map((e) => `
    <div class="item">
      <span class="badge ${e.kind}">${EVENT_LABEL[e.kind] || esc(e.kind)}</span>
      <div class="item-main"><div class="item-title">${esc(e.item)}</div>${e.detail ? `<div class="item-sub">${esc(e.kind === "granted" ? `${e.minutes} min · ${e.detail}` : e.detail)}</div>` : ""}</div>
      <div class="item-meta">${timeOf(e.t)}</div>
    </div>`), "Nothing yet. Decisions appear here once a session starts.");
}

// ---------- Schedule ----------

function buildSchedule() {
  $("days").innerHTML = DAYS.map((d) => `<button class="chip ${dayOn.has(d) ? "active" : ""}" data-day="${d}">${d[0].toUpperCase() + d.slice(1)}</button>`).join("");
  $("days").addEventListener("click", (e) => {
    const b = e.target.closest("[data-day]");
    if (!b) return;
    dayOn.has(b.dataset.day) ? dayOn.delete(b.dataset.day) : dayOn.add(b.dataset.day);
    b.classList.toggle("active");
  });
  $("add-block").onclick = async () => {
    const start = $("block-start").value, end = $("block-end").value, scope = $("block-scope").value.trim();
    $("block-error").textContent = "";
    if (!start || !end || start >= end) return ($("block-error").textContent = "The block has to end after it starts.");
    if (!dayOn.size) return ($("block-error").textContent = "Pick at least one day.");
    if (scope.length < 8) return ($("block-error").textContent = "Describe what the block is for.");
    await api().add_block({ days: DAYS.filter((d) => dayOn.has(d)), start, end, scope });
    $("block-scope").value = "";
    poll();
  };
  $("blocks").addEventListener("click", async (e) => {
    const b = e.target.closest("[data-remove]");
    if (!b) return;
    const r = await api().remove_block(+b.dataset.remove);
    if (r.error) $("block-error").textContent = r.error;
    poll();
  });
}

function renderSchedule() {
  const locked = !!(S.session && S.session.locked);
  const label = (days) => (days.length === 7 ? "Every day" : days.join(",") === "mon,tue,wed,thu,fri" ? "Weekdays"
    : days.map((d) => d[0].toUpperCase() + d.slice(1)).join(", "));
  const rows = S.schedule.map((b, i) => `
    <div class="item">
      <div class="item-time" style="width:110px">${esc(b.start)} – ${esc(b.end)}</div>
      <div class="item-main"><div class="item-title">${esc(b.scope)}</div><div class="item-sub">${esc(label(b.days || DAYS))}</div></div>
      <button class="btn btn-ghost" data-remove="${i}" ${locked ? "disabled title=\"Locked during a session\"" : ""}>Remove</button>
    </div>`);
  const sig = JSON.stringify([S.schedule, locked]);
  if ($("blocks").dataset.sig !== sig) {  // don't rebuild under the cursor every second
    fill("blocks", rows, "No blocks yet. Add one below and it runs every week.");
    $("blocks").dataset.sig = sig;
  }
}

// ---------- Settings ----------

function buildSettings() {
  $("warning").oninput = () => ($("warning-value").textContent = `${$("warning").value}s`);
  $("tiers").addEventListener("click", (e) => {
    const b = e.target.closest("[data-tier]");
    if (!b || b.dataset.tier === chosenTier) return;
    chosenTier = b.dataset.tier;
    $("tiers").querySelectorAll(".option").forEach((x) => x.classList.toggle("active", x === b));
    saveSetting({ tier: chosenTier });
  });
  // Every control saves itself as soon as it changes.
  const toggles = { screenshots: "use_screenshots", autostart: "autostart", tray: "show_tray",
                    "auto-update": "auto_update", mascot: "mascot", "emergency-stop": "emergency_stop" };
  for (const [id, key] of Object.entries(toggles)) $(id).onchange = () => saveSetting({ [key]: $(id).checked });
  $("warning").onchange = () => saveSetting({ warning_seconds: +$("warning").value });
  $("mascot-name").onchange = () => saveSetting({ mascot_name: $("mascot-name").value });
  $("api-key").onchange = async () => {  // fires on Enter or leaving the field
    const key = $("api-key").value.trim();
    if (!key) return;
    const r = await api().save_settings({ api_key: key });
    if (r.error) {
      $("key-desc").textContent = r.error;
      $("key-desc").classList.add("error");
      return;
    }
    $("api-key").value = "";
    $("api-key").placeholder = "Saved. Paste a new key to replace it";
    $("key-desc").classList.remove("error");
    keyDesc(r.provider);
    settingsLoaded = false;  // the prices per check depend on the service
    poll();
  };
  $("claim-credit").onclick = async () => {
    $("claim-credit").disabled = true;
    const r = await api().claim_credit();
    $("claim-credit").disabled = false;
    if (r.error) {
      $("credit-desc").textContent = r.error;
      $("credit-desc").classList.add("error");
      return;
    }
    settingsLoaded = false;
    poll();
  };
  $("beta-code").onchange = async () => {
    const code = $("beta-code").value.trim();
    if (!code) return;
    const r = await api().save_settings({ beta_code: code });
    $("beta-desc").classList.toggle("error", !!r.error);
    if (r.error) { $("beta-desc").textContent = r.error; return; }
    $("beta-code").value = "";
    settingsLoaded = false;
    poll();
  };
  $("beta-off").onclick = async () => {
    const r = await api().save_settings({ beta: false });
    if (r.error) { $("beta-desc").textContent = r.error; $("beta-desc").classList.add("error"); return; }
    settingsLoaded = false;
    poll();
  };
  $("check-updates").onclick = async () => {
    $("check-updates").disabled = true;
    $("update-result").textContent = "Checking…";
    const r = await api().check_updates();
    $("update-result").textContent = r.message;
    $("check-updates").disabled = false;
  };
  $("uninstall").onclick = async () => {
    const r = await confirmDialog({
      title: "Uninstall Kairos?", body: "This removes the app and stops it starting at login.",
      ok: "Uninstall", danger: true, check: "Also delete settings, API key and history",
    });
    if (!r) return;
    const res = await api().uninstall(r.checked);
    if (res.error) $("saved").textContent = res.error;
  };
}

let savedTimer = null;
function keyDesc(provider) {
  $("key-desc").textContent = (provider ? `Using ${provider}. ` : "From Anthropic, OpenAI, Google Gemini or OpenRouter. ") +
    "Stored only on this computer.";
}

async function saveSetting(changes) {
  await api().save_settings(changes);
  $("saved").textContent = "Saved";
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => ($("saved").textContent = ""), 1800);
  poll();
}

function renderSettings() {
  if (settingsLoaded) return;
  settingsLoaded = true;
  const c = S.config, locked = !!(S.session && S.session.locked);
  chosenTier = c.tier;
  $("tiers").innerHTML = S.tiers.map((t) => `
    <button class="option ${t.id === c.tier ? "active" : ""}" data-tier="${t.id}">
      <div class="opt-title"><span>${t.label}</span><span class="opt-cost">${t.cents >= 0.1 ? "~" : ""}${cents(t.cents)}</span></div>
      <div class="opt-note">${t.note}</div>
    </button>`).join("");
  $("api-key").placeholder = c.has_key ? "Saved. Paste a new key to replace it" : c.env_key ? `Using ${c.env_key}` : "Paste your API key";
  keyDesc(c.provider);
  $("credit-row").classList.toggle("hidden", !c.credit_offer);
  if (c.free_credit && !c.has_key) {
    api().credit_left().then((r) => {
      const left = r.left == null ? "" : r.left <= 0.005 ? " It's used up: add your own key to keep going." : ` $${r.left.toFixed(2)} left.`;
      $("key-desc").textContent = `Using your free credit.${left} Paste your own key any time.`;
    });
  }
  $("screenshots").checked = c.use_screenshots;
  $("warning").value = c.warning_seconds;
  $("warning-value").textContent = `${c.warning_seconds}s`;
  $("autostart").checked = c.autostart;
  $("tray").checked = c.show_tray;
  $("auto-update").checked = c.auto_update;
  $("mascot").checked = c.mascot;
  $("mascot-name").value = c.mascot_name;
  $("emergency-stop").checked = c.emergency_stop;
  // Turning them off is always allowed; turning them back on waits until a locked session ends.
  $("emergency-stop").disabled = locked && !c.emergency_stop;
  const { left, of } = S.emergency;
  $("emergency-desc").textContent = `End a locked session early when you really have to, up to ${of} times ever. ` +
    (left ? `${left} left.` : "All used.") + " Turn this off to make locked sessions unbreakable.";
  $("version-line").textContent = `Version ${S.version}`;
  $("tray-desc").textContent = S.platform === "mac" ? "Show Kairos in the menu bar." : "Show Kairos in the corner of the taskbar.";
  for (const id of ["api-key", "autostart", "uninstall"]) $(id).disabled = locked;
  $("beta-code").classList.toggle("hidden", c.beta);
  $("beta-off").classList.toggle("hidden", !c.beta);
  $("beta-off").disabled = locked;
  $("beta-desc").classList.remove("error");
  $("beta-desc").textContent = c.beta ? "On. Accountability is in the sidebar." : "Have a beta code? Enter it to try features that are still being tested.";
  $("settings-lock-note").textContent = locked ? "Some settings are locked until this session ends." : "Changes save automatically.";
}

// ---------- Accountability ----------

let accSavedTimer = null;
async function saveAccountability(changes, descId) {
  const r = await api().save_settings(changes);
  if (descId) {
    $(descId).classList.toggle("error", !!r.error);
    $(descId).dataset.normal ??= $(descId).textContent;
    $(descId).textContent = r.error || $(descId).dataset.normal;
    if (r.error) return r;
  }
  $("acc-saved").textContent = "Saved";
  clearTimeout(accSavedTimer);
  accSavedTimer = setTimeout(() => ($("acc-saved").textContent = ""), 1800);
  accountabilityLoaded = false;
  poll();
  return r;
}

function buildAccountability() {
  $("contact").onchange = async () => {
    const value = $("contact").value.trim();
    if (value === S.config.contact) return;
    if (!value && !(await confirmDialog({
      title: "Stop daily reports?", body: `${S.config.contact} will be told you've turned them off.`, ok: "Stop reports", danger: true,
    }))) { $("contact").value = S.config.contact; return; }
    saveAccountability({ accountability_contact: value }, "contact-desc");
  };
  $("cc-self").onchange = () => saveAccountability({ accountability_cc_self: $("cc-self").checked });
  $("report-time").onchange = () => $("report-time").value && saveAccountability({ accountability_time: $("report-time").value });
  $("report-name").onchange = () => saveAccountability({ accountability_name: $("report-name").value });
  $("smtp-user").onchange = () => saveAccountability({ smtp_user: $("smtp-user").value.trim() }, "smtp-user-desc");
  $("smtp-host").onchange = () => saveAccountability({ smtp_host: $("smtp-host").value });
  $("smtp-password").onchange = async () => {
    if (!$("smtp-password").value) return;
    await saveAccountability({ smtp_password: $("smtp-password").value });
    $("smtp-password").value = "";
  };
  $("own-account").onchange = () => {
    ownAccountOpen = $("own-account").checked;
    showOwnAccount(ownAccountOpen);
    // Turning it off goes back to sending through Kairos (forgets the app password).
    if (!$("own-account").checked && S.config.has_smtp_password) saveAccountability({ smtp_password: null });
  };
  $("open-reports").onclick = () => api().open_reports();
  $("send-test").onclick = async () => {
    $("send-test").disabled = true;
    $("test-result").textContent = "Sending…";
    const r = await api().send_test();
    $("test-result").textContent = r.error || "Sent. Ask them to check it arrived (and isn't in spam).";
    $("test-result").classList.toggle("error", !!r.error);
    $("send-test").disabled = false;
  };
}

let ownAccountOpen = false;  // switched on, password not saved yet
function showOwnAccount(on) {
  document.querySelectorAll(".own-account").forEach((r) => r.classList.toggle("hidden", !on));
}

function renderAccountability() {
  const c = S.config, locked = !!(S.session && S.session.locked);
  const p = c.report_problem;  // these two refresh live; the fields only when the page opens
  $("report-problem").classList.toggle("hidden", !(p && c.contact));
  $("report-problem").textContent = p ? `Reports aren't getting through: ${p.error}. It keeps trying every few minutes.` : "";
  const last = c.last_report && new Date(c.last_report * 1000);
  $("last-report").textContent = !c.contact ? "Add a contact to start daily reports."
    : last ? `Last report sent ${last.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" })} at ${timeOf(c.last_report)}.`
    : `First report goes at ${c.report_time}.`;
  if (accountabilityLoaded) return;
  accountabilityLoaded = true;
  $("contact").value = c.contact;
  $("cc-self").checked = c.cc_self;
  $("report-time").value = c.report_time;
  $("report-name").value = c.report_name;
  $("smtp-user").value = c.smtp_user;
  $("smtp-host").value = c.smtp_host;
  $("smtp-password").placeholder = c.has_smtp_password ? "Saved (type to replace)" : "xxxx xxxx xxxx xxxx";
  const own = c.has_smtp_password || ownAccountOpen;
  $("own-account").checked = own;
  showOwnAccount(own);
  $("own-account-desc").textContent = c.relay
    ? "Reports are sent by Kairos, nothing to set up. Turn this on to send them from your own address instead."
    : "Turn this on for Kairos to email reports from your address. Otherwise they're saved to the folder below for you to send (a Claude task can do it).";
  for (const id of ["contact", "report-time", "report-name", "smtp-user", "smtp-password", "smtp-host"]) $(id).disabled = locked;
  $("own-account").disabled = locked;
  $("send-test").disabled = !c.contact;
  $("intro-row").classList.toggle("hidden", !c.has_sender);
  $("reports-dir-desc").textContent = `Each day's report is also saved here as a text file: ${c.reports_dir}`;
  $("acc-lock-note").textContent = locked ? "These are locked until this session ends." : "";
}

// ---------- About ----------

function renderAbout() {
  const [a, , e] = S.tiers;
  $("about-cost").textContent = `about ${cents(e.cents)}–${cents(a.cents)} per new app or site.`;
  $("version").textContent = `Kairos ${S.version}`;
}

// ---------- loop ----------

function renderSidebar() {
  const s = S.session;
  $("sidebar-status").innerHTML = s
    ? `<div class="status-line"><span class="dot live"></span>In session</div><div class="status-sub">${clock(s.remaining)} left${s.locked ? " · Locked" : ""}</div>`
    : `<div class="status-line"><span class="dot"></span>Not in a session</div><div class="status-sub">Blocking is off</div>`;
}

function render() {
  if (!S) return;
  const navItem = document.querySelector('.nav-item[data-page="accountability"]');
  if (navItem) navItem.classList.toggle("hidden", !S.config.beta);
  if (page === "accountability" && !S.config.beta) return show("settings");
  renderSidebar();
  if (page === "focus") renderFocus();
  if (page === "activity") renderActivity();
  if (page === "schedule") renderSchedule();
  if (page === "accountability") renderAccountability();
  if (page === "settings") renderSettings();
  if (page === "about") renderAbout();
}

async function poll() {
  try { S = await api().state(); render(); } catch (e) { console.error(e); }
}

// ---------- zoom: Ctrl + / - / 0 and Ctrl + wheel (the web view's own shortcuts are off) ----------

const ZOOM_STEPS = [0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2];
let zoom = 1;
try { zoom = +localStorage.getItem("zoom") || 1; } catch {}
function setZoom(z) {
  zoom = z;
  document.documentElement.style.zoom = z;
  try { localStorage.setItem("zoom", z); } catch {}
}
function stepZoom(dir) {
  const i = ZOOM_STEPS.findIndex((s) => s >= zoom - 0.001);
  const at = i === -1 ? ZOOM_STEPS.length - 1 : i;
  setZoom(ZOOM_STEPS[Math.max(0, Math.min(ZOOM_STEPS.length - 1, at + dir))]);
}
setZoom(zoom);
document.addEventListener("keydown", (e) => {
  if (!e.ctrlKey || e.altKey) return;
  if (e.key === "=" || e.key === "+") stepZoom(1);
  else if (e.key === "-" || e.key === "_") stepZoom(-1);
  else if (e.key === "0") setZoom(1);
  else return;
  e.preventDefault();
});
window.addEventListener("wheel", (e) => {
  if (!e.ctrlKey) return;
  e.preventDefault();
  stepZoom(e.deltaY < 0 ? 1 : -1);
}, { passive: false });

document.addEventListener("click", (e) => {
  const a = e.target.closest("[data-link]");
  if (a) { e.preventDefault(); api().open_link(a.dataset.link); }
});

window.addEventListener("pywebviewready", () => {
  buildNav(); buildFocus(); buildSchedule(); buildAccountability(); buildSettings();
  show("focus");
  poll();
  setInterval(poll, 1000);
});
